#include "videodbushandler.h"


VideoDBusHandler::VideoDBusHandler(QObject *parent)
    : QObject{parent}
{
    registerDBus();
}

QString VideoDBusHandler::getTime() const
{
    return time;
}

void VideoDBusHandler::setTime(const QString &newTime)
{
    if (time == newTime)
        return;
    time = newTime;
    emit timeChanged();
}

QString VideoDBusHandler::getDate() const
{
    return date;
}

void VideoDBusHandler::setDate(const QString &newDate)
{
    if (date == newDate)
        return;
    date = newDate;
    emit dateChanged();
}

// Tạo video serivce, để những thằng khác dùng
VideoDBusHandler *VideoDBusHandler::getInstance()
{
    static VideoDBusHandler* tmp = new VideoDBusHandler();
    return tmp;
}

void VideoDBusHandler::registerDBus()
{
    QDBusConnection connect = QDBusConnection::sessionBus();

    if (!connect.isConnected()){
        qDebug()<<"Không thể kết nối tới video d-bus";
        return;
    }

    // đăng ký tên dịch và đường dẫn
    bool checkRegister = connect.registerService("Video.Service");
    bool checkObj = connect.registerObject("/VideoService", m_videoInterface,this,
                                           QDBusConnection::ExportAllContents);
    if (!(checkObj && checkRegister)){
        qDebug()<<"Đăng ký video DBus thất bại";
    }

    //Broadcast signal từ /VideoService rằng dịch vụ này đã được tạo xong
    QDBusMessage message = QDBusMessage::createSignal("/VideoService", m_videoInterface,"VideoServiceCreated");
    connect.send(message);

    connect.connect("","/HomeScreen/Service","HomeScreen.DbusController","HomeAppServiceCreated",this,SLOT(connectToHome()));
    connectToHome();

    connect.connect("","/SettingService","com.fpt.SettingServiceInterface","SettingServiceCreated",this,SLOT(connectToSettingApp()));
    connectToSettingApp();

    connect.connect("","/MediaPlayer/Service","MediaPlayer.DbusController","MediaPlayerServiceCreated",this,SLOT(connectToMediaApp()));
    connectToMediaApp();
}

// hàm này được gọi từ hàm setListener
void VideoDBusHandler::onMessageReceived(QString msg)
{
    QJsonDocument doc = QJsonDocument::fromJson(msg.toUtf8());
    QString msgID = doc.object().value("msg").toString();
    QJsonObject jsonObj = doc.object().value("data").toObject();

    qDebug() << msg;

    if (msgID == "addNewListener")
    {
        qDebug()<<jsonObj.value("ServiceName").toString();
        Listener newProfileApp;

        newProfileApp.setServiceName(jsonObj.value("ServiceName").toString());
        newProfileApp.setInterface(jsonObj.value("ServiceInterface").toString());
        newProfileApp.setPath(jsonObj.value("Path").toString());
        m_listeners.append(newProfileApp);
    }
}


// Gọi method của tất cả listeners: home, music, setting
void VideoDBusHandler::callMethod(const QString &functionName, const QList<QVariant> &listVar,  const QString &target)
{
    qDebug() << m_listeners.length();
    foreach (Listener appInfo, m_listeners) if(target == "" || target == appInfo.serviceName())
    {
        qDebug()<<"ServiceName: "<<appInfo.serviceName()<<", Path: "<<appInfo.path()<<", ServiceInterface: "<<appInfo.interface()
                << ", methodName: "<<functionName;
        QDBusMessage message = QDBusMessage::createMethodCall(
            appInfo.serviceName(),
            appInfo.path(),            // Đường dẫn đối tượng
            appInfo.interface(),       // Interface chứa phương thức
            functionName                // Tên phương thức
            );

        // Thêm tham số vào message
        foreach (QVariant var, listVar) {
            message << var.toString();
        }

        QDBusReply<void> reply = QDBusConnection::sessionBus().call(message);
        qDebug()<<"end call";

        // test kq reply
        if(!reply.isValid()){
            qDebug()<<"Error: "<<reply.error().message();
        }
    }
}

void VideoDBusHandler::onSongChange(QString songImagePath, QString soneName, QString artist)
{

}

void VideoDBusHandler::connectToHome()
{
    AppHomeService::getInstance()->setListeners("Video.Service","/VideoService", m_videoInterface);
}

void VideoDBusHandler::connectToSettingApp()
{
    SettingDbusService::getInstance()->setListeners("Video.Service","/VideoService", m_videoInterface);
}

void VideoDBusHandler::connectToMediaApp()
{
    MediaPlayerService::getInstance()->setListeners("Video.Service","/VideoService", m_videoInterface);
}

void VideoDBusHandler::onShowRequested()
{
    ScreenController::getInstance()->setIsShow(true);
}

void VideoDBusHandler::onRequestPause()
{
    emit pause();
}

void VideoDBusHandler::onLanguageChanged(QString lang)
{
    LanguageController::getInstance()->setLanguage(lang);
}

void VideoDBusHandler::onVolumnChanged(QString vol)
{
    emit volumeChanged(vol.toInt()*10);
}

void VideoDBusHandler::onDateTimeChanged(QString time, QString date)
{
    setDate(date);
    setTime(time);
}

void VideoDBusHandler::backToHome()
{
    ScreenController::getInstance()->setIsShow(false);
    callMethod("onShowRequested",{},"HomeScreen.HomeScreen");
}

QString Listener::path() const
{
    return m_path;
}

void Listener::setPath(const QString &newPath)
{
    m_path = newPath;
}

QString Listener::interface() const
{
    return m_interface;
}

void Listener::setInterface(const QString &newInterface)
{
    m_interface = newInterface;
}

QString Listener::serviceName() const
{
    return m_serviceName;
}

void Listener::setServiceName(const QString &newServiceName)
{
    m_serviceName = newServiceName;
}
