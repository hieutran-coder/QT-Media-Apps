#ifndef VIDEODBUSHANDLER_H
#define VIDEODBUSHANDLER_H

#include<QDebug>
#include <QObject>
#include<QMetaObject>
#include<QMetaClassInfo>
#include<QVariant>

#include<QDBusConnection>
#include<QDBusMessage>
#include<QDBusReply>

#include<QJsonDocument>
#include<QJsonObject>
#include<QJsonArray>
#include<QJsonValue>
#include <AppHomeInterfaceDBus.h>
#include <screencontroller.h>
#include <MediaPlayerInterfaceDBus.h>
#include <SettingInterfaceDBus.h>
#include <videoplayercontroller.h>
#include <languageController.h>
struct Listener
{
    Listener(){}

    QString m_serviceName;
    QString m_path;
    QString m_interface;

public:
    QString serviceName() const;
    void setServiceName(const QString &newServiceName);
    QString path() const;
    void setPath(const QString &newPath);
    QString interface() const;
    void setInterface(const QString &newInterface);
};



class VideoDBusHandler : public QObject,public AppHomeInterfaceDBus,public MediaPlayerInterfaceDBus,public SettingInterfaceDBus
{
    Q_OBJECT
    Q_CLASSINFO("Service", "Video.Serivce")
    Q_CLASSINFO("Path", "/VideoService")
    Q_CLASSINFO("Interface", "com.fpt.VideoServiceInterface")
    Q_PROPERTY(QString date READ getDate WRITE setDate NOTIFY dateChanged FINAL)
    Q_PROPERTY(QString time READ getTime WRITE setTime NOTIFY timeChanged FINAL)
public:
    static VideoDBusHandler* getInstance();
    void registerDBus();

    QString getDate() const;
    void setDate(const QString &newDate);

    QString getTime() const;
    void setTime(const QString &newTime);

public slots:
    void onMessageReceived(QString msg);
    void callMethod(const QString &functionName, const QList<QVariant> &listVar, const QString &target = "");

    void onSongChange(QString songImagePath, QString soneName, QString artist) override;
    void onShowRequested() override;
    void onRequestPause() override;
    void onLanguageChanged(QString lang) override;
    void onVolumnChanged(QString vol) override;
    void onDateTimeChanged(QString time, QString date) override;

    void connectToHome();
    void connectToSettingApp();
    void connectToMediaApp();
    void backToHome();

signals:
    void pause();
    void volumeChanged(int tmp);

    void dateChanged();

    void timeChanged();

private:
    VideoDBusHandler(QObject *parent = nullptr);
    QList<Listener> m_listeners;

    const QString m_videoServiceName = "Video.Service";
    const QString m_videoPath = "/VideoService";
    const QString m_videoInterface = "com.fpt.VideoServiceInterface";

    QString date;
    QString time;
};

#endif // VIDEODBUSHANDLER_H
