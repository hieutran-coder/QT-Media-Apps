#ifndef VIDEOPLAYERCONTROLLER_H
#define VIDEOPLAYERCONTROLLER_H

#include <QObject>
#include<QMediaPlayer>
#include<QMediaMetaData>
#include<QDebug>
#include<QAudioOutput>
#include<videoplayermodel.h>
#include<videodbushandler.h>

class VideoPlayerController : public QObject
{
    Q_OBJECT
    Q_PROPERTY(VideoPlayerModel *playerModel READ getPlayerModel WRITE setPlayerModel NOTIFY playerModelChanged FINAL)


public:
    VideoPlayerController(QObject *parent = nullptr);

    ~VideoPlayerController();
public:
    // xử lý singleton
    // static VideoPlayerController* getInstance(){
    //     static VideoPlayerController instance;
    //     return &instance;
    // }
    Q_INVOKABLE void requestPlay();
    Q_INVOKABLE void seek(qint64 position);

    // //Get/Set video position and duration
    // qint64 videoPos() const;
    // qint64 duration() const;

    // void setVideoPos(qint64 newVideoPos);
    // void setDuration(qint64 newDuration);

    void convertDuration(qint64 duration);
    void convertVideoPos(qint64 pos);





// Signal tự sinh ra
    VideoPlayerModel *getPlayerModel() const;
    void setPlayerModel(VideoPlayerModel *newPlayerModel);

    void requestPlay(QString source);
    QMediaPlayer *mediaPlayer() ;
    void setMediaPlayer(QMediaPlayer *newMediaPlayer);

    QAbstractVideoSurface *surface() const;
    void setSurface(QAbstractVideoSurface *newSurface);

signals:
       // void videoSinkChanged();
        void videoPosChanged();
        void durationChanged();

// Các slot này sẽ được kết nối khi pos và state thay đổi
        void playerModelChanged();

        void mediaPlayerChanged();

        void surfaceChanged();

    public slots:
    void handlePlayingTimeChanged(qint64 position);
    void handlePlaybackStatusChanged(QMediaPlayer::State status);

    void handleDurationChange(qint64 duration);
    void requestPause();
    void changeVolume(int vol);


private:
    QMediaPlayer* m_mediaPlayer;
    QAudioOutput* m_audioOutput;

    VideoPlayerModel* playerModel;
    QAbstractVideoSurface *m_surface;

    Q_PROPERTY(QMediaPlayer *mediaPlayer READ mediaPlayer WRITE setMediaPlayer NOTIFY mediaPlayerChanged FINAL)
    Q_PROPERTY(QAbstractVideoSurface *surface READ surface WRITE setSurface NOTIFY surfaceChanged FINAL)
};

#endif // VIDEOPLAYERCONTROLLER_H


/*
qint64: Giúp nhất quán trên các platform khác nhau
    //  Vì mediaPlayer bắn 1 signal chứa thông điệp cũng kiểu 64 bit

*/
