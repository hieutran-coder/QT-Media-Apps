#include "videolistcontroller.h"


VideoListController* VideoListController::m_instance = nullptr;

VideoListController::VideoListController(QObject *parent)
    : QObject{parent}
{
    videoListModel = new VideoListModel();
    videoPlayerController = new VideoPlayerController();

    connect(VideoDBusHandler::getInstance(),SIGNAL(pause()),videoPlayerController,SLOT(requestPause()));
    connect(VideoDBusHandler::getInstance(),SIGNAL(volumeChanged(int)),videoPlayerController,SLOT(changeVolume(int)));
    LOG_INFO;

}


void VideoListController::setCurVideo(int index){
    qDebug()<<"go to function cur video";

    if (videoListModel->getCurIndex() != index){

        videoListModel->setCurIndex(index);
        videoListModel->setCurVideo(videoListModel->getVideoInfoList().at(index));

        QString source = videoListModel->getCurVideo()->source();
        setCurrentSource( "file://" + source);

        qDebug()<<"source:"<<m_currentSource;
        videoPlayerController->requestPlay(source);

        VideoDBusHandler::getInstance()->callMethod("onVideoChanged", {videoListModel->getCurVideo()->fileName()});

    }
}

QString VideoListController::currentSource() const
{
    return m_currentSource;
}

void VideoListController::setCurrentSource(const QString &newCurrentSource)
{
    if (m_currentSource == newCurrentSource)
        return;
    m_currentSource = newCurrentSource;
    emit currentSourceChanged();
}


/// expose to QML
void VideoListController::intialize(QQmlContext *context)
{
    LOG_INFO<<m_initialized;

    if (!m_initialized){
        m_initialized = true;
        context->setContextProperty("VIDEO_CONTROLLER", this);
        context->setContextProperty("VIDEO_LIST", this->getVideoListModel()); // Loi boi vi VIDEO_LIST khong phai instance
        context->setContextProperty("VIDEO_PLAYER", this->getVideoPlayerController());
    }

}

VideoListController::~VideoListController(){
    LOG_INFO;
}

VideoListController *VideoListController::getInstance(){
    if (m_instance == nullptr){

        m_instance = new VideoListController();
    }
    return m_instance;
}

VideoListModel *VideoListController::getVideoListModel() const
{
    return videoListModel;
}

void VideoListController::setVideoListModel(VideoListModel *newVideoListModel)
{
    if (videoListModel == newVideoListModel)
        return;
    videoListModel = newVideoListModel;
    emit videoListModelChanged();
}

VideoPlayerController *VideoListController::getVideoPlayerController() const
{
    return videoPlayerController;
}

void VideoListController::setVideoPlayerController(VideoPlayerController *newVideoPlayerController)
{
    if (videoPlayerController == newVideoPlayerController)
        return;
    videoPlayerController = newVideoPlayerController;
    emit videoPlayerControllerChanged();
}
