#ifndef VIDEOLISTCONTROLLER_H
#define VIDEOLISTCONTROLLER_H

#include <QObject>
#include<videolistmodel.h>
#include<videoplayercontroller.h>
#include<loghelper.h>
#include<QQmlContext>
#include<videodbushandler.h>

class VideoListController : public QObject
{
    Q_OBJECT
public:
    explicit VideoListController(QObject *parent = nullptr);

public:
    ~VideoListController();
    static VideoListController *getInstance();
    VideoListModel *getVideoListModel() const;
    void setVideoListModel(VideoListModel *newVideoListModel);


    VideoPlayerController *getVideoPlayerController() const;
    void setVideoPlayerController(VideoPlayerController *newVideoPlayerController);

    // Khoi tao controller
    void intialize(QQmlContext* context);

    Q_INVOKABLE   void setCurVideo(int index);


    Q_INVOKABLE QString currentSource() const;


    void setCurrentSource(const QString &newCurrentSource);

signals:
    void videoListModelChanged();
    void videoPlayerControllerChanged();

    void currentSourceChanged();

private:
    VideoListModel* videoListModel;
    VideoPlayerController* videoPlayerController;
    VideoDBusHandler* m_Dbus;

    Q_PROPERTY(VideoListModel *videoListModel READ getVideoListModel WRITE setVideoListModel NOTIFY videoListModelChanged FINAL)
    Q_PROPERTY(VideoPlayerController *videoPlayerController READ getVideoPlayerController WRITE setVideoPlayerController NOTIFY videoPlayerControllerChanged FINAL)


    static VideoListController *m_instance;
    bool m_initialized;
    QString m_currentSource;

    Q_PROPERTY(QString currentSource READ currentSource WRITE setCurrentSource NOTIFY currentSourceChanged FINAL)
};

#endif // VIDEOLISTCONTROLLER_H
