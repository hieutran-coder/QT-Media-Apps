#include "languageController.h"

LanguageController *LanguageController::getInstance()
{
    static LanguageController* tmp = new LanguageController();
    return tmp;
}

void LanguageController::setLanguage(QString lang)
{
    if(translator){
        qApp->removeTranslator(translator);
        translator = new QTranslator();
    }
    if(lang == "English"){
        if(translator->load(":/localization/videoLang_en.qm")){
            qApp->installTranslator(translator);
        }
    }
    if(lang == "Vietnam"){
        if(translator->load(":/localization/videoLang_vn.qm")){
            qApp->installTranslator(translator);
        }
    }
    emit languageChanged();
}

LanguageController::LanguageController(QObject *parent)
    : QObject{parent}
{
    translator = new QTranslator();
}
