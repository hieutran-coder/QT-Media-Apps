#include "videoplayercontroller.h"
#include <QMediaPlayer>
#include<QAbstractVideoSurface>
#include<QMediaMetaData>
#include "videolistcontroller.h"


// Khởi tạo bài hát
VideoPlayerController::VideoPlayerController(QObject *parent)
    : QObject{parent}, m_surface(nullptr)
{

    playerModel = new VideoPlayerModel();
    playerModel->setVideoPos(0);
    playerModel->setState(QMediaPlayer::StoppedState);


    m_mediaPlayer = new QMediaPlayer(); // hủy khi parent hủy
    m_mediaPlayer->setMedia(QUrl::fromLocalFile("/home/lonely/Downloads/y2mate.com - nhạc ngắn gọn_480p.mp4"));
    m_mediaPlayer->setVideoOutput(m_surface);

    QObject::connect(m_mediaPlayer, &QMediaPlayer::stateChanged, this, &VideoPlayerController::handlePlaybackStatusChanged);  //Cần biết message mà signal gửi đến
    QObject::connect(m_mediaPlayer, &QMediaPlayer::positionChanged, this, &VideoPlayerController::handlePlayingTimeChanged);
    QObject::connect(m_mediaPlayer, &QMediaPlayer::durationChanged, this, &VideoPlayerController::handleDurationChange);
}

VideoPlayerController::~VideoPlayerController(){
    m_surface = nullptr;
    m_mediaPlayer->setVideoOutput(m_surface);
}

// Goi khi moi khoi tao
void VideoPlayerController::requestPlay()
{

    VideoDBusHandler::getInstance()->callMethod("onRequestPause",{});
    VideoDBusHandler::getInstance()->callMethod("onVideoChanged", {VideoListController::getInstance()->getVideoListModel()->getCurVideo()->fileName()});
    if (playerModel->state() == QMediaPlayer::StoppedState)
    {
        m_mediaPlayer->setMedia(QUrl::fromLocalFile("/home/lonely/Downloads/y2mate.com - nhạc ngắn gọn_480p.mp4"));
        m_mediaPlayer->play();
    }

    // nhảy vào 2 cái
    else if (playerModel->state() == QMediaPlayer::PlayingState){
        m_mediaPlayer->pause();
    }
    else if (playerModel->state() == QMediaPlayer::PausedState){
        m_mediaPlayer->play();
    }
}

// Goi khi click vao list
void VideoPlayerController::requestPlay(QString source)
{
    source = "file://" + source;
    qDebug() <<"day la 1 cai source"<< source;
    // Có 3 trạng thái: stop, playing, pause
    VideoDBusHandler::getInstance()->callMethod("onRequestPause",{});

    if (playerModel->state() == QMediaPlayer::StoppedState){

            //m_mediaPlayer->setSource(QUrl("file:///home/hieutran/Documents/QT_Framework/QT_Advance/FINAL_QTA_MOCK/build/Desktop_Qt_6_7_2-Debug/Videos/StillHere-Wooyoung2PM-6963317.mp4"));
        m_mediaPlayer->setMedia(QUrl(source));
        m_mediaPlayer->play();
    }
    else if (playerModel->state() == QMediaPlayer::PlayingState){
        //m_mediaPlayer->stop();
        m_mediaPlayer->setMedia(QUrl(source));
        m_mediaPlayer->play();
    }
    else if (playerModel->state() == QMediaPlayer::PausedState){
        //m_mediaPlayer->stop();
        m_mediaPlayer->setMedia(QUrl(source));
        m_mediaPlayer->play();

    }
}




void VideoPlayerController::seek(qint64 position)
{
    //m_mediaPlayer->setPosition(position);    // position change -->  handlePlayingTimeChanged đc gọi tới --> Video PosChange
    //m_videoPos = position; // ko cần
    playerModel->setVideoPos(position);
    m_mediaPlayer->setPosition(playerModel->videoPos());

}


void VideoPlayerController::handlePlayingTimeChanged(qint64 position)
{

    playerModel->setVideoPos(position);
    convertVideoPos(position);
}

void VideoPlayerController::handlePlaybackStatusChanged(QMediaPlayer::State status)
{
   // qDebug()<<"state: "<<playerModel->state();

    playerModel->setState(status);

}

void VideoPlayerController::handleDurationChange(qint64 duration)
{

    playerModel->setDuration(duration);
    convertDuration(playerModel->duration());

}

QAbstractVideoSurface *VideoPlayerController::surface() const
{
    return m_surface;
}

void VideoPlayerController::setSurface(QAbstractVideoSurface *newSurface)
{
    if (m_surface == newSurface)
        return;
    m_surface = newSurface;
    m_mediaPlayer->setVideoOutput(m_surface);
    emit surfaceChanged();
}

QMediaPlayer *VideoPlayerController::mediaPlayer()
{
    return m_mediaPlayer;
}

void VideoPlayerController::setMediaPlayer(QMediaPlayer *newMediaPlayer)
{
    if (m_mediaPlayer == newMediaPlayer)
        return;
    m_mediaPlayer = newMediaPlayer;
    emit mediaPlayerChanged();
}

VideoPlayerModel *VideoPlayerController::getPlayerModel() const
{
    return playerModel;
}

void VideoPlayerController::setPlayerModel(VideoPlayerModel *newPlayerModel)
{
    if (playerModel == newPlayerModel)
        return;
    playerModel = newPlayerModel;
    emit playerModelChanged();
}

void VideoPlayerController::convertDuration(qint64 duration){
    qint64 mm = duration/60000;
    qint64 ss = (duration -mm*60000)/1000;

    qDebug()<<mm<<":"<<ss;
    QString sDuration;
    if (ss>9)
        sDuration = QString::number(mm) + ":" + QString::number(ss);
    else
        sDuration = QString::number(mm) + ":" + "0" + QString::number(ss);
    playerModel->setSDuration(sDuration);
}



void VideoPlayerController::convertVideoPos(qint64 pos){
    qint64 mm = pos/60000;
    qint64 ss = (pos -mm*60000)/1000;

    qDebug()<<mm<<":"<<ss;
    QString sVideoPos;
    if (ss>9)
        sVideoPos = QString::number(mm) + ":" + QString::number(ss);
    else
        sVideoPos = QString::number(mm) + ":" + "0" + QString::number(ss);
    playerModel->setSVideoPos(sVideoPos);

}

void VideoPlayerController::requestPause()
{
    m_mediaPlayer->pause();
}

void VideoPlayerController::changeVolume(int vol)
{
    m_mediaPlayer->setVolume(vol);
}


// void VideoPlayerController::setVideoSink(QVideoSink *newVideoSink)
// {
//     qDebug()<<"aaa";
//     if (m_videoSink == newVideoSink)
//         return;
//     m_mediaPlayer->setVideoSink(newVideoSink);
//     m_videoSink = newVideoSink;

//     emit videoSinkChanged();
// }
