#ifndef LANGUAGECONTROLLER_H
#define LANGUAGECONTROLLER_H

#include <QObject>
#include <QTranslator>
#include <QCoreApplication>

class LanguageController : public QObject
{
    Q_OBJECT
public:
    static LanguageController* getInstance();
    void setLanguage(QString lang);

signals:
    void languageChanged();

private:
    explicit LanguageController(QObject *parent = nullptr);
    QTranslator* translator;
};

#endif // LANGUAGECONTROLLER_H
