#include "screencontroller.h"
#include "AppEnums.h"
//#include "loghelper.h"
ScreenController* ScreenController::m_instance = nullptr;

ScreenController::ScreenController(QObject *parent)
    : QObject{parent},
    m_initialized(false),
    m_engine(nullptr)

{
    qDebug()<<"ScreenController constructed";
}

ScreenController::~ScreenController(){
    qDebug()<<"ScreenController destructed";
    m_engine =nullptr;
}

ScreenController *ScreenController::getInstance(){
    if (m_instance == nullptr){
        m_instance = new ScreenController();
    }
    return m_instance;
}

void ScreenController::initialize(QQmlContext* context){
    qDebug()<<"m_initialized:"<<m_initialized;

    // expose screen model and controler to qml
    if(!m_initialized)
    {
        m_initialized = true;
        context->setContextProperty("SCREEN_MODEL", &m_model);
        context->setContextProperty("SCREEN_CONTROLLER", this);
    }

}



//Copy from Project mook
void ScreenController::initializeScreen(QQmlApplicationEngine *engine)
{
    if(m_engine == nullptr)
    {
        m_engine = engine;

        // load main qml
        m_engine->load(QUrl(QStringLiteral(MAIN_QML)));
        // show home menu screen
        pushScreen(AppEnums::SCREEN_ID_VIDEO_LIST);
    }
}

void ScreenController::pushScreen(int screenId)
{
    qDebug() <<"ScreenID: "<< screenId;
    m_screenStack.push(screenId);
    reloadScreen();
}

void ScreenController::replaceScreen(int screenId)
{
    qDebug()<<"ScreenID:" << screenId;
    if(!m_screenStack.isEmpty())
    {
        m_screenStack.pop();
    }
    m_screenStack.push(screenId);
    reloadScreen();
}

void ScreenController::popScreen()
{
    qDebug() << "count: "<<m_screenStack.count();
    if(m_screenStack.count() > 1)
    {
        m_screenStack.pop();
        reloadScreen();
    }
}

void ScreenController::popToRoot()
{
    qDebug() <<"count: "<< m_screenStack.count();
    while(m_screenStack.count() > 1)
    {
        m_screenStack.pop();
    }
    reloadScreen();
}

void ScreenController::reloadScreen()
{
    // if(!m_screenStack.isEmpty())
    // {
    //     QString screenName = ScreenNameMap.value(m_screenStack.top());
    //     // reload screen on qml
    //     m_model.setCurScreen(screenName);
    //     if((m_engine != nullptr) && (m_engine->rootObjects().count() > 0))
    //     {
    //         QMetaObject::invokeMethod(m_engine->rootObjects().at(0), "reloadScreen");
    //     }
    // }
}

bool ScreenController::getIsShow() const
{
    return isShow;
}

void ScreenController::setIsShow(bool newIsShow)
{
    if (isShow == newIsShow)
        return;
    isShow = newIsShow;
    emit isShowChanged();
}

