#ifndef SCREENCONTROLLER_H
#define SCREENCONTROLLER_H

#include <QObject>
#include<QQmlContext>
#include<QQmlApplicationEngine>
#include<screenmodel.h>
#include<QStack>

class ScreenController : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool isShow READ getIsShow WRITE setIsShow NOTIFY isShowChanged FINAL)
public:
    explicit ScreenController(QObject *parent = nullptr);

public:
    ~ScreenController();

    //singleton pattern
    static ScreenController *getInstance();

    //khoi tao controller
    void initialize(QQmlContext* context);
    void initializeScreen(QQmlApplicationEngine* engine);

    // Screen transition: Co ve la cac screen chong len nhau
    Q_INVOKABLE void pushScreen(int screenID);
    Q_INVOKABLE void replaceScreen(int screenID);
    Q_INVOKABLE void popScreen();
    Q_INVOKABLE void popToRoot();

    bool getIsShow() const;
    void setIsShow(bool newIsShow);

signals:
    void isShowChanged();

private:
    void reloadScreen();

private:
    static ScreenController* m_instance;
    bool m_initialized;
    ScreenModel m_model;
    QStack<int> m_screenStack;
    QQmlApplicationEngine *m_engine;

    bool isShow = false;
};

#endif // SCREENCONTROLLER_H
