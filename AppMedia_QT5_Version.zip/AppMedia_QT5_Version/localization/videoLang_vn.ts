<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="vi_VN">
<context>
    <name>main</name>
    <message>
        <location filename="../main.qml" line="8"/>
        <source>Hello World</source>
        <translation>Xin </translation>
    </message>
    <message>
        <location filename="../main.qml" line="20"/>
        <source>Video &gt; List</source>
        <translation>Video-&gt;Danh sách</translation>
    </message>
    <message>
        <location filename="../main.qml" line="51"/>
        <source>Video &gt; Play</source>
        <translation>Video-&gt;Phát video</translation>
    </message>
</context>
</TS>
