#ifndef APPENUMS_H
#define APPENUMS_H

#include <QObject>
#include <QMap>

#define MAIN_QML "qrc:/main.qml"

class AppEnums: public QObject
{
    Q_OBJECT


public:
    enum SCREEN_ID: int
    {
        SCREEN_ID_VIDEO_SCREEN,
        SCREEN_ID_VIDEO_LIST
    };
    Q_ENUM(SCREEN_ID)
};
const QMap<int, QString> ScreenNameMap
{
    {AppEnums::SCREEN_ID_VIDEO_SCREEN, "qrc:/VideoScreen.qml"},
    {AppEnums::SCREEN_ID_VIDEO_LIST, "qrc:/VideoList.qml"}
};



#endif // APPENUMS_H
