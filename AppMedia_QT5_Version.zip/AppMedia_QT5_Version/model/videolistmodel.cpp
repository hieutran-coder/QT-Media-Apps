#include "videolistmodel.h"
#include "QFileInfo"
#include "QDir"
#include "QEventLoop"
#include "QMediaPlayer"
#include "QAudioOutput"
#include"QMediaMetaData"
VideoListModel::VideoListModel(QObject *parent)
    : QAbstractListModel{parent}
{


     QFileInfo fileInfo(__FILE__);
    // Xử lý lấy tên file từ folder song.
    QString sourceDirPath = fileInfo.absolutePath();
    qDebug()<<sourceDirPath;
    QDir directory(sourceDirPath + "/videos/" ); // QDir không hỗ trợ tiền tố "file:///"
    QStringList filters;
    filters <<"*.mp4";

    qDebug()<<directory;
    QStringList mp3Files = directory.entryList(filters,QDir::Files);
    qDebug()<<mp3Files;

    foreach(QString file, mp3Files){
        qDebug()<<file;
        VideoInfo* info = new VideoInfo();
        info->setFileName(file);
        info->setSource(sourceDirPath + "/videos/" + file);

        videoInfoList.append(info);
    }



    // Lay meta data
    QMediaPlayer *m_player = new QMediaPlayer();
    //QAudioOutput *m_audio = new QAudioOutput();
   // m_player->setAudioOutput(m_audio);

    QStringList files = mp3Files;
    QVector<QString> titles, albumTitles, albumArtists, singlers;
    QVector<int> durations;

    int i = 0;
    // Code học từ Vũ
    foreach (const QString &file, files) {
        qDebug() << "File:______________" << file;
        //QString fullPath = dir.absoluteFilePath(file);
        //qDebug()<<sourceDirPath + "/Songs/" + file;
        m_player->setMedia(QUrl::fromLocalFile(sourceDirPath + "/videos/" + file));

        QEventLoop loop;
        bool metadataHandled = false;

        // metaDataChanged = false khi nào? --> Khi chưa lấy được metadata
        // metaDataChanged chuyển sang true khi nào?

        // Kết nối signal metaDataChanged với một hàm lambda
        QObject::connect(m_player, &QMediaPlayer::metaDataAvailableChanged, [&titles,&albumTitles,&albumArtists,&singlers,&durations, m_player, &loop, &metadataHandled, &file, this, &files, &i]() {
            if (!metadataHandled) {
                // Lấy giá trị từ MetaData bằng QVariant
                QVariant title = m_player->metaData(QMediaMetaData::Title);
                QVariant namesinger = m_player->metaData(QMediaMetaData::ContributingArtist);
                QVariant publisher = m_player->metaData(QMediaMetaData::Publisher);
                videoInfoList[i]->setVideoTitle(title.toString());
                qDebug()<<"Video info "<<i<< ":"<<videoInfoList[i]->videoTitle();
                // Display metadata
                qDebug()<<"before add file is file: "<<file;
                qDebug()<<title<<","<<publisher;
                metadataHandled = true;
                loop.quit();
            }
        });
        m_player->play();
        loop.exec();  // Wait until metadata is loaded before processing the next file (có nghĩa là khi hàm quit của loop được gọi)
        m_player->pause();
        i++;
    }
    curVideo = videoInfoList[0];

}

QHash<int, QByteArray> VideoListModel::roleNames() const
{
    return mRoleMap;
}

int VideoListModel::rowCount(const QModelIndex &parent) const
{
    return videoInfoList.count();
}

QVariant VideoListModel::data(const QModelIndex &index, int role) const
{
    if(index.row()<0||index.row()>videoInfoList.count())
    {
        return QVariant();
    }

    VideoInfo* videoInfo = videoInfoList.at(index.row());

    if(role == MEDIA_VIDEO_TITLE){
        return videoInfo->videoTitle();
    }
    else if (role == MEDIA_FILE_NAME){
        return videoInfo->fileName();
    }
    else if (role == MEDIA_VIDEO_PUBLISHER) {
        return videoInfo->publisher();
    }
    else if (role == MEDIA_VIDEO_SOURCE){
        return videoInfo->source();
    }
    else{
        return QVariant();
    }

}

QStringList getAllFilesOfAFolder(QString postfix){
    // Xử lý lấy tên file từ folder song.
    QFileInfo fileInfo(__FILE__);
    QString sourceDirPath = fileInfo.absolutePath();

    qDebug()<<sourceDirPath;
    QDir directory(sourceDirPath + "/videos/" ); // QDir không hỗ trợ tiền tố "file:///"
    QStringList filters;
    filters <<postfix;

    qDebug()<<directory;
    QStringList mp3Files = directory.entryList(filters,QDir::Files);
    qDebug()<<mp3Files;
    foreach(QString file, mp3Files){
        qDebug()<<file;
    }
    return mp3Files;

}
void VideoListModel::loadMediaList()
{


}

VideoInfo *VideoListModel::getCurVideo() const
{
    return curVideo;
}

void VideoListModel::setCurVideo(VideoInfo *newCurVideo)
{
    if (curVideo == newCurVideo)
        return;
    curVideo = newCurVideo;
    emit curVideoChanged();

}

QList<VideoInfo *> VideoListModel::getVideoInfoList() const
{
    return videoInfoList;
}

void VideoListModel::setVideoInfoList(const QList<VideoInfo *> &newVideoInfoList)
{
    videoInfoList = newVideoInfoList;
}

int VideoListModel::getCurIndex() const
{
    return curIndex;
}

void VideoListModel::setCurIndex(int newCurIndex)
{
    curIndex = newCurIndex;
}





