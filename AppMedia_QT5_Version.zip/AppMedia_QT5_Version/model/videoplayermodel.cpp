#include "videoplayermodel.h"

VideoPlayerModel::VideoPlayerModel(QObject *parent)
    : QObject{parent}
{}

qint64 VideoPlayerModel::videoPos() const
{
    return m_videoPos;
}

void VideoPlayerModel::setVideoPos(qint64 newVideoPos)
{
    if (m_videoPos == newVideoPos)
        return;
    m_videoPos = newVideoPos;
    emit videoPosChanged();
}

qint64 VideoPlayerModel::duration() const
{
    return m_duration;
}

void VideoPlayerModel::setDuration(qint64 newDuration)
{
    if (m_duration == newDuration)
        return;
    m_duration = newDuration;
    emit durationChanged();
}

QMediaPlayer::State VideoPlayerModel::state() const
{
    return m_state;
}

void VideoPlayerModel::setState(const QMediaPlayer::State &newState)
{
    if (m_state == newState)
        return;
    m_state = newState;
    emit stateChanged();
}

QString VideoPlayerModel::sDuration() const
{
    return m_sDuration;
}

void VideoPlayerModel::setSDuration(const QString &newSDuration)
{
    if (m_sDuration == newSDuration)
        return;
    m_sDuration = newSDuration;
    emit sDurationChanged();
}

QString VideoPlayerModel::sVideoPos() const
{
    return m_sVideoPos;
}

void VideoPlayerModel::setSVideoPos(const QString &newSVideoPos)
{
    if (m_sVideoPos == newSVideoPos)
        return;
    m_sVideoPos = newSVideoPos;
    emit sVideoPosChanged();
}

bool VideoPlayerModel::fullScreenStatus() const
{
    return m_fullScreenStatus;
}

void VideoPlayerModel::setFullScreenStatus(bool newFullScreenStatus)
{
    if (m_fullScreenStatus == newFullScreenStatus)
        return;
    m_fullScreenStatus = newFullScreenStatus;
    emit fullScreenStatusChanged();
}
