#ifndef VIDEOINFO_H
#define VIDEOINFO_H

#include <QObject>

class VideoInfo : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString source READ source WRITE setSource NOTIFY sourceChanged FINAL)
    Q_PROPERTY(QString videoTitle READ videoTitle WRITE setVideoTitle NOTIFY videoTitleChanged FINAL)
    Q_PROPERTY(QString publisher READ publisher WRITE setPublisher NOTIFY publisherChanged FINAL)
    Q_PROPERTY(QString fileName READ fileName WRITE setFileName NOTIFY fileNameChanged FINAL)

public:
    explicit VideoInfo(QObject *parent = nullptr);

    QString source() const;
    void setSource(const QString &newSource);

    QString publisher() const;
    void setPublisher(const QString &newPublisher);

    QString videoTitle() const;
    void setVideoTitle(const QString &newVideoTitle);

    QString fileName() const;
    void setFileName(const QString &newFileName);


signals:
    void sourceChanged();
    void videoNameChanged();
    void publisherChanged();
    void videoTitleChanged();
    void fileNameChanged();

private:
    QString m_source;
    QString m_publisher;
    QString m_videoTitle;
    QString m_fileName;
};

#endif // VIDEOINFO_H
