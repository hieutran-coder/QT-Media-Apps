#ifndef SCREENMODEL_H
#define SCREENMODEL_H

#include <QObject>

// Muc dich class la chi de luu cur screen thoi
class ScreenModel : public QObject
{
    Q_OBJECT

    //na na curVideo
    Q_PROPERTY(QString curScreen READ curScreen WRITE setCurScreen NOTIFY curScreenChanged FINAL)

public:
    explicit ScreenModel(QObject *parent = nullptr);
    ~ScreenModel();




    QString curScreen() const;
    void setCurScreen(const QString &newCurScreen);

signals:
    void curScreenChanged();
private:
    QString m_curScreen;
};

#endif // SCREENMODEL_H
