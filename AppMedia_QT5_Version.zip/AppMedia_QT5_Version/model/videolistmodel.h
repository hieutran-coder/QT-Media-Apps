#ifndef VIDEOLISTMODEL_H
#define VIDEOLISTMODEL_H

#include <QObject>
#include<videoinfo.h>
#include<QAbstractListModel>
#include<videodbushandler.h>
class VideoListModel : public QAbstractListModel
{
    Q_OBJECT
public:
    enum MEDIA_ROLE: int
    {
        MEDIA_FILE_NAME = Qt::UserRole + 1,
        MEDIA_VIDEO_TITLE,
        MEDIA_VIDEO_PUBLISHER,
        MEDIA_VIDEO_SOURCE
    };

    explicit VideoListModel(QObject *parent = nullptr);
    QHash<int,QByteArray> roleNames() const;
    int rowCount(const QModelIndex &parent = QModelIndex()) const;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;

    void loadMediaList();
    // void addVideoInfo();
    // void removeVideoInfo();


signals:

    void curVideoChanged();

public:
    VideoInfo *getCurVideo() const;
    void setCurVideo(VideoInfo *newCurVideo);


    QList<VideoInfo *> getVideoInfoList() const;
    void setVideoInfoList(const QList<VideoInfo *> &newVideoInfoList);

    int getCurIndex() const;
    void setCurIndex(int newCurIndex);




private:
    QList<VideoInfo*> videoInfoList;
    QHash<int, QByteArray> mRoleMap = {
        {MEDIA_FILE_NAME, "MediaFileName"},
        {MEDIA_VIDEO_TITLE, "MediaVideoTitle"},
        {MEDIA_VIDEO_SOURCE,"MediaVideoSource"},
        {MEDIA_VIDEO_PUBLISHER, "MediaVideoPublisher"}
    };

    VideoInfo* curVideo;
    int curIndex = -1;


    Q_PROPERTY(VideoInfo *curVideo READ getCurVideo WRITE setCurVideo NOTIFY curVideoChanged FINAL)
};

#endif // VIDEOLISTMODEL_H
