#include "screenmodel.h"

ScreenModel::ScreenModel(QObject *parent)
    : QObject{parent}
{}
ScreenModel::~ScreenModel(){

}


QString ScreenModel::curScreen() const
{
    return m_curScreen;
}

void ScreenModel::setCurScreen(const QString &newCurScreen)
{
    if (m_curScreen == newCurScreen)
        return;
    m_curScreen = newCurScreen;
    emit curScreenChanged();
}
