#ifndef VIDEOPLAYERMODEL_H
#define VIDEOPLAYERMODEL_H

#include <QObject>

#include <QObject>
#include<QMediaPlayer>
#include<QMediaMetaData>
#include<QDebug>
#include<QAudioOutput>

class VideoPlayerModel : public QObject
{
    Q_OBJECT
    Q_PROPERTY(qint64 videoPos READ videoPos WRITE setVideoPos NOTIFY videoPosChanged FINAL)
    Q_PROPERTY(qint64 duration READ duration WRITE setDuration NOTIFY durationChanged FINAL)
    Q_PROPERTY(QString sVideoPos READ sVideoPos WRITE setSVideoPos NOTIFY sVideoPosChanged FINAL)
    Q_PROPERTY(QString sDuration READ sDuration WRITE setSDuration NOTIFY sDurationChanged FINAL)
    Q_PROPERTY(QMediaPlayer::State state READ state WRITE setState NOTIFY stateChanged FINAL)
    Q_PROPERTY(bool fullScreenStatus READ fullScreenStatus WRITE setFullScreenStatus NOTIFY fullScreenStatusChanged FINAL)

    // Q_PROPERTY(bool fullScreenStatus READ fullScreenStatus WRITE setFullScreenStatus NOTIFY fullScreenStatusChanged FINAL);
public:
    explicit VideoPlayerModel(QObject *parent = nullptr);

    qint64 videoPos() const;
    void setVideoPos(qint64 newVideoPos);

    qint64 duration() const;
    void setDuration(qint64 newDuration);

    QMediaPlayer::State state() const;
    void setState(const QMediaPlayer::State &newState);

    QString sDuration() const;
    void setSDuration(const QString &newSDuration);

    QString sVideoPos() const;
    void setSVideoPos(const QString &newSVideoPos);

    bool fullScreenStatus() const;
    void setFullScreenStatus(bool newFullScreenStatus);

signals:
    void videoPosChanged();
    void durationChanged();

    void stateChanged();

    void sDurationChanged();

    void sVideoPosChanged();

    void fullScreenStatusChanged();

private:
    qint64 m_videoPos;
    qint64 m_duration;


    QMediaPlayer::State m_state;
    QString m_sDuration;
    QString m_sVideoPos;
    bool m_fullScreenStatus = false;
};

#endif // VIDEOPLAYERMODEL_H
