#include "videoinfo.h"

VideoInfo::VideoInfo(QObject *parent)
    : QObject{parent}
{}

QString VideoInfo::source() const
{
    return m_source;
}

void VideoInfo::setSource(const QString &newSource)
{
    if (m_source == newSource)
        return;
    m_source = newSource;
    emit sourceChanged();
}



QString VideoInfo::publisher() const
{
    return m_publisher;
}

void VideoInfo::setPublisher(const QString &newPublisher)
{
    if (m_publisher == newPublisher)
        return;
    m_publisher = newPublisher;
    emit publisherChanged();
}

QString VideoInfo::videoTitle() const
{
    return m_videoTitle;
}

void VideoInfo::setVideoTitle(const QString &newVideoTitle)
{
    if (m_videoTitle == newVideoTitle)
        return;
    m_videoTitle = newVideoTitle;
    emit videoTitleChanged();
}

QString VideoInfo::fileName() const
{
    return m_fileName;
}

void VideoInfo::setFileName(const QString &newFileName)
{
    if (m_fileName == newFileName)
        return;
    m_fileName = newFileName;
    emit fileNameChanged();
}
