#ifndef APPENGINE_H
#define APPENGINE_H

#include "AppEnums.h"
#include <QObject>
#include <QGuiApplication> // muc dich
#include <QQmlApplicationEngine>
#include <loghelper.h>
#include <videolistcontroller.h>
#include <screencontroller.h>
#include <videodbushandler.h>
#include <QQmlContext>
#include <languageController.h>
class AppEngine : public QObject
{
    Q_OBJECT
private:
    explicit AppEngine(QObject *parent = nullptr);

public:
    ~AppEngine();

    static AppEngine *getInstance();

    void initialize(QGuiApplication *app);

private:

    void registerQmlObjects();

    void createControllers();
    void initControllers();
    void initScreens();

signals:

private:
    static AppEngine* m_instance;
    bool m_initialized;

    QGuiApplication* m_app;
    QQmlApplicationEngine m_engine;
};


#endif // APPENGINE_H


