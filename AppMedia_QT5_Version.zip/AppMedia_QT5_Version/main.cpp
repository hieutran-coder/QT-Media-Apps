#include "videoplayercontroller.h"
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include<QMediaPlayer>
#include<QAudioOutput>
#include<QVideoFrame>
#include<QQmlContext>
#include<videolistmodel.h>
#include<videolistcontroller.h>
#include<appengine.h>
#include"videodbushandler.h"
#include <QDir>
#include <QPluginLoader>
#include <StatusBarPluginInterface.h>

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;

    QDir pluginDir = QDir::currentPath();
    pluginDir.cd("../StatusBarPlugin");


    const QStringList entries = pluginDir.entryList( QStringList() << "*.so", QDir::Files);
    foreach (QString name, entries) {
        QPluginLoader pluginLoader(pluginDir.absoluteFilePath(name));
        QObject *plugin = pluginLoader.instance();
        if(plugin)
        {
            StatusBarPluginInterface* myInterface = qobject_cast<StatusBarPluginInterface*> (plugin);
            if(myInterface)
            {
                qDebug() << "plugin:" << name;
                myInterface->registerObj(&engine);
            }
            else
            {
                qDebug() << "Failed to cast to interface";
            }
        }
        else
        {
            qDebug() << "Failed to load plugin: " << pluginLoader.errorString();
        }
    }

    AppEngine::getInstance()->initialize(&app);    
    return app.exec();
}

/*
1. Video:
    - Understanding Library, TestPlayVideo
    VideoScreen:
        1. ScrollBar animation: Làm sao để chạy thứ tự text?
            -> 1. Sequence animation
            -> 2. onSTOP
        2. Perfecting phan video
            -> 1. Làm thêm các nút bật mở videos
    HomeScreen:
        - Nhận signal từ:
                    - Video
                    - Music
                    - Setting to change langugae
    Dbus:
        - Understanding
                - file setting cua QL
                    -> implement it
                - file Dbus cua QL
                - Vd a Hung
                - Bai 8
                sharemem:
                    -QTA_Day10
        - Add
    Setting:
        - Understanding QL Setting
        - Video: Receive signal from setting
    Plugin:
        - Vd a Hung

V
*/
