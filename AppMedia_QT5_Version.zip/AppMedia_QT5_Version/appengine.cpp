#include "appengine.h"
AppEngine* AppEngine::m_instance = nullptr;

AppEngine::AppEngine(QObject *parent)
    : QObject{parent}
{}

AppEngine::~AppEngine(){
    LOG_INFO;
    m_app = nullptr;

}

AppEngine *AppEngine::getInstance(){

    if(m_instance== nullptr){
        m_instance = new AppEngine();
    }
    return m_instance;
}

void AppEngine::initialize(QGuiApplication *app){
    LOG_INFO<<m_initialized;

    if (!m_initialized){
        m_initialized = true;
        m_app = app;

        registerQmlObjects();
        createControllers();
        initControllers();
        initScreens();
    }
}

void AppEngine::registerQmlObjects(){ // register appEnums
    LOG_INFO<<" => Start ";

    qmlRegisterType<AppEnums>("AppEnums", 1,0,"AppEnums");
}

void AppEngine::createControllers(){
    LOG_INFO<<" => Start";
    VideoListController::getInstance();
    ScreenController::getInstance();
    VideoDBusHandler::getInstance();
    LOG_INFO<<" => End";
}

void AppEngine::initControllers(){  // expose controller to QML
    LOG_INFO<<" => Start";

    VideoListController::getInstance()->intialize(m_engine.rootContext());
    m_engine.rootContext()->setContextProperty("DbusHandler",VideoDBusHandler::getInstance());
    m_engine.rootContext()->setContextProperty("ScreenController",ScreenController::getInstance());
    QObject::connect(LanguageController::getInstance(),SIGNAL(languageChanged()),&m_engine,SLOT(retranslate()));
}

void AppEngine::initScreens(){
    LOG_INFO<<" => Start";
    ScreenController::getInstance()->initializeScreen(&m_engine);
}
